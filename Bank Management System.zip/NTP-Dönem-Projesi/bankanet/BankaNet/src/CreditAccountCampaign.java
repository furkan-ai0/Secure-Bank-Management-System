public class CreditAccountCampaign {
    public static void showCampaign() {
        System.out.println("""
                Kredili hesap kampanyası, düzenli gelir beyanı sağlayan müşterilerimize %1,2 faiz oranıyla kredi tanımlamaktadır.
                Kampanyadan yararlanabilmek için en az 6 aydır aktif müşteri olmanız gerekmektedir.
                Detaylar için bank@net.com a bilgi/yenihesap yazıp mail yollayınız.""");
    }
}
