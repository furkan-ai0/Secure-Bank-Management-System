public class CurrentAccountCampaign {
    public static void showCampaign() {
        System.out.println("""
                Vadesiz hesap kampanyamızdan yararlanarak her ay düzenli para transferlerinizi ücretsiz gerçekleştirebilirsiniz.
                Kampanyaya katılmak için hesabınıza aylık minimum 5.000 TL giriş yapılması gerekmektedir.
                Detaylar için bank@net.com adresine bilgi/vadesizhesap yazarak mail yollayınız.""");
    }
}
