import java.util.Scanner;

public interface Settings {
    void displaySettings();

    void updatePassword(Scanner scanner);

    void updateUsername(Scanner scanner);
}
