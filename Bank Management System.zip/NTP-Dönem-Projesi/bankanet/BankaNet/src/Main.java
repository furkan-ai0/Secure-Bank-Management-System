public class Main {
    public static void main(String[] args) {
        StartScreen startScreen = new StartScreen("default", "default");
        startScreen.printMessage();
    }
}
