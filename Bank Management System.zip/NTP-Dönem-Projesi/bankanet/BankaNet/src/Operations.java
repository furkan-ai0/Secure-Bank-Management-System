import java.util.Scanner;

public interface Operations {
    void displayOperations();

    void customerDelete(Scanner scanner);

    void customerAdd(Scanner scanner);
}
