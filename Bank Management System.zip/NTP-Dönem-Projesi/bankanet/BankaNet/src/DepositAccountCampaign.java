public class DepositAccountCampaign {
    public static void showCampaign() {
        System.out.println("""
                Vadeli hesap kampanyasından yararlanarak yeni bir vadeli hesap açtığınızda %5 oranında ek faiz kazanın.
                Ancak, vadeli hesap açılışı için minimum 10.000 TL bakiye gerekmektedir.
                Detaylar için bank@net.com adresine bilgi/vadeli yazıp mail yollayınız.""");
    }
}
